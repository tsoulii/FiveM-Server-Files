# esx_panicbutton
Panic Button for ESX

I have modified this code from various Panic Buttons. I did this to only work for ESX and to only allow Police be able to use this.This is a Police Panic Button for ESX. By default if your Police & you press Key F10 it will give you the Name, Street, & Cross Street of the Officer who pressed their Panic Button.

# Requirement:
* Police Job
  * [esx_policejob](https://github.com/ESX-Org/esx_policejob)

# Download & Installation
1) Download the .zip.
2) Extract the .zip or Open the .zip.
3) Place `esx_panicbutton` in your ESX Directory
4) Add `start esx_panicbutton` to your server.cfg

# Credits/Original Code
* [Vespura](https://forum.fivem.net/u/vespura)
  * [Emergency Location Message](https://forum.fivem.net/t/emergency-location-message/55844)

# Support
I will be closing all suport for this. As there is a much better way to do a Panic Button for the Police Job & have only cops see it. Follow the Steps Below to do the new & better way.

client/main.lua
```
Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		if IsControlJustPressed(0, Keys['G']) then
			SendPoliceDistressSignal()
		end
	end
end)

function SendPoliceDistressSignal()
	local playerPed = GetPlayerPed(-1)
	local coords	= GetEntityCoords(playerPed)

	ESX.ShowNotification(_U('distress_sent'))
	TriggerServerEvent('esx_phone:send', 'police', _U('police_distress_message'), false, {
		x = coords.x,
		y = coords.y,
		z = coords.z
	})
end
```
locales/en.lua
```
  ['distress_sent'] = 'distress signal has been sent to available units!',
  ['police_distress_message'] = 'police attention required: OFFICER IN NEED OF ASSISTANCE!',
```

# Other
If you like this please check out some of my other stuff like
* [esx_customui](https://github.com/HumanTree92/esx_customui)
* [esx_hospital](https://github.com/HumanTree92/esx_hospital)
* [esx_extraitems](https://github.com/HumanTree92/esx_extraitems)
* [esx_aircraftshop](https://github.com/HumanTree92/esx_aircraftshop)
* [esx_boatshop](https://github.com/HumanTree92/esx_boatshop)
* [esx_eden_aircraftgarage](https://github.com/HumanTree92/esx_eden_aircraftgarage)
* [esx_eden_boatgarage](https://github.com/HumanTree92/esx_eden_boatgarage)
* [esx_eden_garage](https://github.com/HumanTree92/esx_eden_garage)
* [esx_panicbutton](https://github.com/HumanTree92/esx_panicbutton)
* [FiveM_CustomMapAddons](https://github.com/HumanTree92/FiveM_CustomMapAddons)

# Visit Velociti Entertainment
* [TS3](http://www.velocitientertainment.com/ts3/)
* [Discord](https://discord.gg/azEY2kU)
* [Website](www.velocitientertainment.com/)
* [Forums](www.velocitientertainment.com/forum)
* [Servers](www.velocitientertainment.com/servers/)
* [Donate](http://www.velocitientertainment.com/donations/)
* [Steam Group](http://steamcommunity.com/groups/velocitientertainment)
* [Facebook](www.facebook.com/VelocitiEntertainment)
* [Twitter](www.twitter.com/VelocitiEnt)
* [YouTube](www.youtube.com/user/HumanTree92)
* [Twitch](www.twitch.tv/humantree92)
* [eBay](www.ebay.com/usr/humantree92)
* Kik #vegaming
